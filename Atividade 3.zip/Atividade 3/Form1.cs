﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double Imc;
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out double Altura) && double.TryParse(txtPeso.Text, out double Peso))
            {
                if ((Altura <= 0) || (Peso <= 0)) ;
                else
                {
                    Imc = Peso / Math.Pow(Altura, 2);
                    Imc = Math.Pow(Imc, 1);
                    txtImc.Text = Imc.ToString("n1");
                   
                }
                if (Imc<18.5)
                    MessageBox.Show("Magreza");

                if (Imc >= 18.5 && Imc <24.9)
                    MessageBox.Show("Normal");

                if (Imc >= 25 && Imc < 29.9)
                    MessageBox.Show("Sobrepeso");

                if (Imc >= 30 && Imc < 39.9)
                    MessageBox.Show("Obesidade");

                if (Imc > 40)
                    MessageBox.Show("Obesidade Grave");
            }
            else
                MessageBox.Show("Valores inválidos");
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            txtImc.Clear();
            txtAltura.Text= string.Empty;
            txtPeso.Text= "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
