﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCopa0030482213001
{
    internal class Estadio
    {
        public int Id { get; set; }

        public string Nome { get; set; }



        public DataTable Listar()

        {

            SqlDataAdapter daEstadio;



            DataTable dtEstadio = new DataTable();



            try

            {

                daEstadio = new SqlDataAdapter("SELECT * FROM ESTADIO ORDER BY NOME", frmPrincipal.conexao);

                daEstadio.Fill(dtEstadio);

                daEstadio.FillSchema(dtEstadio, SchemaType.Source);

            }

            catch (Exception)

            {

                throw;

            }

            return dtEstadio;

        }
    }
}
