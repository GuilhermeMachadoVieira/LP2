﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    class Mensalista : Empregado // especialização -> herança // : é filho/faz parte da classe empregado
    {
        public Double SalarioMensal { get; set; }


        //sobreescrevendo o método
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        //construtor é o primeiro método que vai executar --> new
        public Mensalista()
        {
            MessageBox.Show("passei por aqui");
        }

        public Mensalista (double x)
        {

        }

        public Mensalista(int matx, string nomex, DateTime datax, double salariox)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salariox;
        }

    }
}
