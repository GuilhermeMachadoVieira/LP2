﻿namespace BSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIRPF = new System.Windows.Forms.Label();
            this.lblSalariofamilia = new System.Windows.Forms.Label();
            this.lblSalarioliquido = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.lblSalariobruto = new System.Windows.Forms.Label();
            this.nudFilhos = new System.Windows.Forms.NumericUpDown();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.txtSalariofamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioliquido = new System.Windows.Forms.TextBox();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtDescontoIRPF = new System.Windows.Forms.TextBox();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnCasado = new System.Windows.Forms.RadioButton();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.mskbxSalariobruto = new System.Windows.Forms.MaskedTextBox();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.mskbxINSS = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).BeginInit();
            this.gbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(102, 54);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(96, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = " Nome Funcionário";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(122, 126);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblFilhos.TabIndex = 1;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(122, 284);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(48, 13);
            this.lblDados.TabIndex = 2;
            this.lblDados.Text = "lblDados";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(125, 332);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAliquotaINSS.TabIndex = 3;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIRPF
            // 
            this.lblAliquotaIRPF.AutoSize = true;
            this.lblAliquotaIRPF.Location = new System.Drawing.Point(122, 364);
            this.lblAliquotaIRPF.Name = "lblAliquotaIRPF";
            this.lblAliquotaIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAliquotaIRPF.TabIndex = 4;
            this.lblAliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalariofamilia
            // 
            this.lblSalariofamilia.AutoSize = true;
            this.lblSalariofamilia.Location = new System.Drawing.Point(122, 393);
            this.lblSalariofamilia.Name = "lblSalariofamilia";
            this.lblSalariofamilia.Size = new System.Drawing.Size(74, 13);
            this.lblSalariofamilia.TabIndex = 5;
            this.lblSalariofamilia.Text = "Salário Familia";
            // 
            // lblSalarioliquido
            // 
            this.lblSalarioliquido.AutoSize = true;
            this.lblSalarioliquido.Location = new System.Drawing.Point(122, 426);
            this.lblSalarioliquido.Name = "lblSalarioliquido";
            this.lblSalarioliquido.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioliquido.TabIndex = 6;
            this.lblSalarioliquido.Text = "Salario Liquido";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Location = new System.Drawing.Point(454, 332);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescontoINSS.TabIndex = 7;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Location = new System.Drawing.Point(455, 368);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescontoIRPF.TabIndex = 8;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // lblSalariobruto
            // 
            this.lblSalariobruto.AutoSize = true;
            this.lblSalariobruto.Location = new System.Drawing.Point(122, 92);
            this.lblSalariobruto.Name = "lblSalariobruto";
            this.lblSalariobruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalariobruto.TabIndex = 9;
            this.lblSalariobruto.Text = "Salário Bruto";
            // 
            // nudFilhos
            // 
            this.nudFilhos.Location = new System.Drawing.Point(254, 124);
            this.nudFilhos.Name = "nudFilhos";
            this.nudFilhos.Size = new System.Drawing.Size(120, 20);
            this.nudFilhos.TabIndex = 10;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(254, 54);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 11;
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Enabled = false;
            this.txtAliquotaINSS.Location = new System.Drawing.Point(224, 325);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaINSS.TabIndex = 12;
            // 
            // txtAliquotaIRPF
            // 
            this.txtAliquotaIRPF.Enabled = false;
            this.txtAliquotaIRPF.Location = new System.Drawing.Point(224, 357);
            this.txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            this.txtAliquotaIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIRPF.TabIndex = 13;
            // 
            // txtSalariofamilia
            // 
            this.txtSalariofamilia.Enabled = false;
            this.txtSalariofamilia.Location = new System.Drawing.Point(224, 390);
            this.txtSalariofamilia.Name = "txtSalariofamilia";
            this.txtSalariofamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalariofamilia.TabIndex = 14;
            // 
            // txtSalarioliquido
            // 
            this.txtSalarioliquido.Enabled = false;
            this.txtSalarioliquido.Location = new System.Drawing.Point(224, 423);
            this.txtSalarioliquido.Name = "txtSalarioliquido";
            this.txtSalarioliquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioliquido.TabIndex = 15;
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Enabled = false;
            this.txtDescontoINSS.Location = new System.Drawing.Point(541, 325);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescontoINSS.TabIndex = 16;
            // 
            // txtDescontoIRPF
            // 
            this.txtDescontoIRPF.Enabled = false;
            this.txtDescontoIRPF.Location = new System.Drawing.Point(541, 361);
            this.txtDescontoIRPF.Name = "txtDescontoIRPF";
            this.txtDescontoIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescontoIRPF.TabIndex = 17;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnF);
            this.gbxSexo.Controls.Add(this.rbtnM);
            this.gbxSexo.Location = new System.Drawing.Point(458, 50);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(183, 89);
            this.gbxSexo.TabIndex = 18;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Checked = true;
            this.rbtnF.Location = new System.Drawing.Point(9, 54);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(31, 17);
            this.rbtnF.TabIndex = 20;
            this.rbtnF.TabStop = true;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Location = new System.Drawing.Point(9, 31);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(34, 17);
            this.rbtnM.TabIndex = 19;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnCasado
            // 
            this.rbtnCasado.AutoSize = true;
            this.rbtnCasado.Location = new System.Drawing.Point(9, 12);
            this.rbtnCasado.Name = "rbtnCasado";
            this.rbtnCasado.Size = new System.Drawing.Size(73, 17);
            this.rbtnCasado.TabIndex = 21;
            this.rbtnCasado.TabStop = true;
            this.rbtnCasado.Text = "Casado(a)";
            this.rbtnCasado.UseVisualStyleBackColor = true;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(211, 202);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(163, 38);
            this.btnVerificar.TabIndex = 22;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // mskbxSalariobruto
            // 
            this.mskbxSalariobruto.Location = new System.Drawing.Point(254, 85);
            this.mskbxSalariobruto.Mask = "9999999,99";
            this.mskbxSalariobruto.Name = "mskbxSalariobruto";
            this.mskbxSalariobruto.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalariobruto.TabIndex = 23;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.rbtnCasado);
            this.pnlCasado.Location = new System.Drawing.Point(458, 145);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(183, 41);
            this.pnlCasado.TabIndex = 24;
            // 
            // mskbxINSS
            // 
            this.mskbxINSS.Location = new System.Drawing.Point(224, 284);
            this.mskbxINSS.Mask = "99,00%";
            this.mskbxINSS.Name = "mskbxINSS";
            this.mskbxINSS.Size = new System.Drawing.Size(100, 20);
            this.mskbxINSS.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(736, 510);
            this.Controls.Add(this.mskbxINSS);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.mskbxSalariobruto);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.txtDescontoIRPF);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.txtSalarioliquido);
            this.Controls.Add(this.txtSalariofamilia);
            this.Controls.Add(this.txtAliquotaIRPF);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.nudFilhos);
            this.Controls.Add(this.lblSalariobruto);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblSalarioliquido);
            this.Controls.Add(this.lblSalariofamilia);
            this.Controls.Add(this.lblAliquotaIRPF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).EndInit();
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIRPF;
        private System.Windows.Forms.Label lblSalariofamilia;
        private System.Windows.Forms.Label lblSalarioliquido;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.Label lblSalariobruto;
        private System.Windows.Forms.NumericUpDown nudFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtAliquotaIRPF;
        private System.Windows.Forms.TextBox txtSalariofamilia;
        private System.Windows.Forms.TextBox txtSalarioliquido;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.TextBox txtDescontoIRPF;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnF;
        private System.Windows.Forms.RadioButton rbtnM;
        private System.Windows.Forms.RadioButton rbtnCasado;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.MaskedTextBox mskbxSalariobruto;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.MaskedTextBox mskbxINSS;
    }
}

