﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double descontoInss = 0;
            double descontoIrpf = 0;
           
            
            if (txtNome.Text == string.Empty)
            {
                MessageBox.Show("O Nome do funcionario esta vazio");
            }
            else
            {
               salarioBruto = Convert.ToDouble(mskbxSalariobruto.Text) ;
                if (salarioBruto <= 800.47)
                {
                    descontoInss = salarioBruto * 0.0765; 
                    txtDescontoINSS.Text = Convert.ToString(descontoInss);
                    mskbxINSS.Text = "07,65";
                }
                else if (salarioBruto >= 800.48 && salarioBruto < 1050 )
                {
                    descontoInss = salarioBruto * 0.0865;
                    txtDescontoINSS.Text = Convert.ToString(descontoInss);
                }
                else if (salarioBruto >= 1050.01 && salarioBruto <1400.77)
                {
                    descontoInss = salarioBruto * 0.09;
                    txtDescontoINSS.Text = Convert.ToString(descontoInss);
                }
                else if (salarioBruto >= 1400.78 && salarioBruto <2801.56)
                {
                    descontoInss = salarioBruto * 0.11;
                    txtDescontoINSS.Text = Convert.ToString(descontoInss);
                }
                else if (salarioBruto> 2512.08)
                {
                    descontoInss = salarioBruto * 3.0817;
                    txtDescontoINSS.Text = Convert.ToString(descontoInss);
                }
              
              if(salarioBruto < 1257.12)
                {
                    
                    txtDescontoIRPF.Text = "Isento";
                }
              else if(salarioBruto <= 1257.13 && salarioBruto >= 2512.08)
                {
                    descontoIrpf = salarioBruto * 0.15;
                    txtDescontoIRPF.Text = Convert.ToString(descontoIrpf);
                }
                else
                {
                    descontoIrpf = salarioBruto * 0.275;
                    txtDescontoIRPF.Text = Convert.ToString(descontoIrpf);
                }
              if (salarioBruto < 435.52)
                {
                    salarioFamilia = 22.33 * Convert.ToDouble(nudFilhos.Value);
                    txtSalariofamilia.Text = Convert.ToString(salarioFamilia);
                }
               else if (salarioBruto > 435.53 && salarioBruto<654.61 )
                {
                    salarioFamilia = 15.74 * Convert.ToDouble(nudFilhos.Value);
                    txtSalariofamilia.Text = Convert.ToString(salarioFamilia);
                }
                else 
                {
                    salarioFamilia = 0 * Convert.ToDouble(nudFilhos.Value);
                    txtSalariofamilia.Text = Convert.ToString(salarioFamilia);
                }
              
                salarioLiquido = salarioBruto - descontoInss - descontoIrpf + salarioFamilia;
                txtSalarioliquido.Text = Convert.ToString(salarioLiquido);

                
            }
        }
    }
}
