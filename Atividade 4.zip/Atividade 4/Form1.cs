﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLadoA.Text, out double LadoA) && double.TryParse(txtLadoB.Text, out double LadoB) &&
                double.TryParse(txtLadoC.Text, out double LadoC))
            {
                if ((LadoA <= 0) || (LadoB <= 0) || (LadoC <= 0));
                else
                {
                    if ((LadoA == LadoB) && (LadoB == LadoC))
                    MessageBox.Show("Triângulo Equilátero");

                    if ((LadoA != LadoB) && (LadoB != LadoC) && (LadoA != LadoC))
                    MessageBox.Show("Triângulo Escaleno");

                    if ((LadoA == LadoB) && (LadoA != LadoC) || 
                        (LadoB == LadoC) && (LadoB != LadoA) ||
                        (LadoC == LadoA) && (LadoC != LadoB))
                   MessageBox.Show("Triângulo Isósceles");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = "";
            txtLadoB.Text = "";
            txtLadoC.Text = "";
        }
    }
}
