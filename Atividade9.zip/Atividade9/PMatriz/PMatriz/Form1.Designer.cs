﻿
namespace PMatriz
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverterValor = new System.Windows.Forms.Button();
            this.btnMercadoria = new System.Windows.Forms.Button();
            this.btnVerificarTotal = new System.Windows.Forms.Button();
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNomesPessoas = new System.Windows.Forms.Button();
            this.btnInverterComFor = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverterValor
            // 
            this.btnInverterValor.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnInverterValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverterValor.Location = new System.Drawing.Point(24, 72);
            this.btnInverterValor.Margin = new System.Windows.Forms.Padding(2);
            this.btnInverterValor.Name = "btnInverterValor";
            this.btnInverterValor.Size = new System.Drawing.Size(158, 69);
            this.btnInverterValor.TabIndex = 0;
            this.btnInverterValor.Text = "Ler 20 números e inverter";
            this.btnInverterValor.UseVisualStyleBackColor = false;
            this.btnInverterValor.Click += new System.EventHandler(this.btnInverterValor_Click);
            // 
            // btnMercadoria
            // 
            this.btnMercadoria.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMercadoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMercadoria.Location = new System.Drawing.Point(209, 72);
            this.btnMercadoria.Margin = new System.Windows.Forms.Padding(2);
            this.btnMercadoria.Name = "btnMercadoria";
            this.btnMercadoria.Size = new System.Drawing.Size(158, 69);
            this.btnMercadoria.TabIndex = 1;
            this.btnMercadoria.Text = " Quantidade e Preço de Mercadorias";
            this.btnMercadoria.UseVisualStyleBackColor = false;
            this.btnMercadoria.Click += new System.EventHandler(this.btnMercadoria_Click);
            // 
            // btnVerificarTotal
            // 
            this.btnVerificarTotal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnVerificarTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificarTotal.Location = new System.Drawing.Point(396, 72);
            this.btnVerificarTotal.Margin = new System.Windows.Forms.Padding(2);
            this.btnVerificarTotal.Name = "btnVerificarTotal";
            this.btnVerificarTotal.Size = new System.Drawing.Size(158, 69);
            this.btnVerificarTotal.TabIndex = 2;
            this.btnVerificarTotal.Text = "Verifica Total";
            this.btnVerificarTotal.UseVisualStyleBackColor = false;
            this.btnVerificarTotal.Click += new System.EventHandler(this.btnVerificarTotal_Click);
            // 
            // btnReverse
            // 
            this.btnReverse.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReverse.Location = new System.Drawing.Point(24, 156);
            this.btnReverse.Margin = new System.Windows.Forms.Padding(2);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(158, 69);
            this.btnReverse.TabIndex = 3;
            this.btnReverse.Text = "Ler 20 números e inverter (Reverse)";
            this.btnReverse.UseVisualStyleBackColor = false;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnArrayList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrayList.Location = new System.Drawing.Point(209, 156);
            this.btnArrayList.Margin = new System.Windows.Forms.Padding(2);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(158, 69);
            this.btnArrayList.TabIndex = 4;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = false;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMedia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(396, 156);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(2);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(158, 69);
            this.btnMedia.TabIndex = 5;
            this.btnMedia.Text = "Média Alunos";
            this.btnMedia.UseVisualStyleBackColor = false;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNomesPessoas
            // 
            this.btnNomesPessoas.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnNomesPessoas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNomesPessoas.Location = new System.Drawing.Point(209, 243);
            this.btnNomesPessoas.Margin = new System.Windows.Forms.Padding(2);
            this.btnNomesPessoas.Name = "btnNomesPessoas";
            this.btnNomesPessoas.Size = new System.Drawing.Size(158, 69);
            this.btnNomesPessoas.TabIndex = 6;
            this.btnNomesPessoas.Text = "Nomes Pessoas";
            this.btnNomesPessoas.UseVisualStyleBackColor = false;
            this.btnNomesPessoas.Click += new System.EventHandler(this.btnNomesPessoas_Click);
            // 
            // btnInverterComFor
            // 
            this.btnInverterComFor.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnInverterComFor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverterComFor.Location = new System.Drawing.Point(24, 243);
            this.btnInverterComFor.Margin = new System.Windows.Forms.Padding(2);
            this.btnInverterComFor.Name = "btnInverterComFor";
            this.btnInverterComFor.Size = new System.Drawing.Size(158, 69);
            this.btnInverterComFor.TabIndex = 7;
            this.btnInverterComFor.Text = "Ler 20 números e inverter (for ao contrário)";
            this.btnInverterComFor.UseVisualStyleBackColor = false;
            this.btnInverterComFor.Click += new System.EventHandler(this.btnInverterComFor_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblTitulo.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTitulo.Location = new System.Drawing.Point(20, 23);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(277, 23);
            this.lblTitulo.TabIndex = 9;
            this.lblTitulo.Text = "Selecione um botão para executar: ";
            this.lblTitulo.Click += new System.EventHandler(this.lblTitulo_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(396, 243);
            this.btnSair.Margin = new System.Windows.Forms.Padding(2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(158, 69);
            this.btnSair.TabIndex = 11;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnInverterComFor);
            this.Controls.Add(this.btnNomesPessoas);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.btnVerificarTotal);
            this.Controls.Add(this.btnMercadoria);
            this.Controls.Add(this.btnInverterValor);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Menu Principall";
            this.TransparencyKey = System.Drawing.Color.Transparent;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInverterValor;
        private System.Windows.Forms.Button btnMercadoria;
        private System.Windows.Forms.Button btnVerificarTotal;
        private System.Windows.Forms.Button btnReverse;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnNomesPessoas;
        private System.Windows.Forms.Button btnInverterComFor;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnSair;
    }
}

